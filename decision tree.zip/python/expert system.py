import tkinter as tk
from PIL import ImageTk, Image


def show_start_page2():
    # Remove the existing buttons from the GUI
    start_button.destroy()
   
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()

    start_label = tk.Label(root, text="Great choice! You could now choose what you prefer, either a PC or a Laptop?")
    start_label.pack()

    start_back_button = tk.Button(root, text="Back to Main Menu", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    start_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    start_option2_button = tk.Button(root, text="PC", command=show_option2_page, fg="white", bg="blue", relief="solid", highlightthickness=40, font=("Times New Roman", 12, "bold"))
    start_option2_button.pack(side="left", padx=10, pady=50, anchor="center")

    start_option2_button = tk.Button(root, text="Laptop", command=show_option2_page, fg="white", bg="blue", relief="solid", highlightthickness=40, font=("Times New Roman", 12, "bold"))
    start_option2_button.pack(side="right", padx=10, pady=50, anchor="center")


def show_option1_page():
    # Remove the existing buttons from the GUI
    clear_window()
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    start_button.destroy()

    # Add a label to the GUI with the option 1 message
    option1_label = tk.Label(root, text="Great choice! You could now choose what you prefer, either a PC or a Laptop?", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option1_label.pack()

    # Add buttons to return to the main screen or choose another option
    

    option1_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option1_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    option1_option2_button = tk.Button(root, text="PC", command=show_option4_page, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option1_option2_button.pack(side="left", padx=10, pady=50, anchor="center")

    option1_option2_button = tk.Button(root, text="Laptop", command=show_laptop_page1, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option1_option2_button.pack(side="right", padx=10, pady=50, anchor="center")

def show_option2_page():
    clear_window()
    # Remove the existing buttons from the GUI
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()

    # Add a label to the GUI with the option 2 message
    option2_label = tk.Label(root, text="Phone Category! Select a phone brand you'd like to buy.", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option2_label.pack()

    # Add buttons to return to the main screen or choose another option
    option2_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option2_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    option2_option1_button = tk.Button(root, text="iPhone", command=show_Iphone_page1, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option2_option1_button.pack(side="left", padx=10, pady=50, anchor="center")

    option2_option1_button = tk.Button(root, text="Android", command=show_Android_page1, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option2_option1_button.pack(side="right", padx=10, pady=50, anchor="center")



def show_option3_page():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()

    # Add a label to the GUI with the option 3 message
    option3_label = tk.Label(root, text="This is where you can select a tablet of your liking based on your usage.", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option3_label.pack()

    # Add buttons to return to the main screen or choose another option
    option3_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option3_back_button = tk.Button(root, text="Professional Work/Drawing", command=protablet, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option3_option1_button = tk.Button(root, text="Normal Usage/Watching", command=normaltablet, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_option1_button.pack(side="right", padx=10, pady=50, anchor="center")

def protablet():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()

    # Add a label to the GUI with the option 3 message
    option3_label = tk.Label(root, text="Pro Devices for Work or Drawing professionally", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option3_label.pack()

    # Add buttons to return to the main screen or choose another option
    option3_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option3_back_button = tk.Button(root, text="iPad Pro 12.9 Inch", command=ipadpro, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option3_option1_button = tk.Button(root, text="Samsung S8 Ultra Tablet", command=s8ultra, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def ipadpro():
    clear_window()
    
    # Load the image
    image = Image.open("ipad PRO.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=protablet, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def s8ultra():
    clear_window()
    
    # Load the image
    image = Image.open("samsung s8 ultra.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=protablet, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def normaltablet():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()

    # Add a label to the GUI with the option 3 message
    option3_label = tk.Label(root, text="Normal Devices for low-intensity activity or just watching", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option3_label.pack()

    # Add buttons to return to the main screen or choose another option
    option3_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option3_back_button = tk.Button(root, text="iPad Air 9", command=ipadair, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option3_option1_button = tk.Button(root, text="Samsung S6 Lite", command=s6lite, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option3_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def ipadair():
    clear_window()
    
    # Load the image
    image = Image.open("ipad air.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=normaltablet, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def s6lite():
    clear_window()
    
    # Load the image
    image = Image.open("samsung s6 lite.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=normaltablet, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()




def show_option4_page():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option4_label = tk.Label(root, text="Do you want to purchase a Cryptominer or a Gaming PC?", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option4_label.pack()

    option4_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option4_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option4_back_button = tk.Button(root, text="Cryptominers", command=show_option5_page, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option4_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option4_option1_button = tk.Button(root, text="Gaming PC", command=show_option6_page, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option4_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_option6_page():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Select the suitable price from the options below", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Price <=5,000AED", command=pc5k, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="Price >=8,000AED", command=pc8k, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")

def pc5k():
    clear_window()
    
    # Load the image
    image = Image.open("gaming pc low.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_option6_page, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def pc8k():
    clear_window()
    
    # Load the image
    image = Image.open("gaming pc high.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_option6_page, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()






def show_option5_page():
    
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option5_label = tk.Label(root, text="Select the suitable price from the options below", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option5_label.pack()

    option5_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option5_back_button = tk.Button(root, text="Price <=20,000AED", command=crypto20k, font=("Times New Roman", 12, "bold"), fg="white", bg="blue", relief="solid", highlightthickness=40)
    option5_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option5_option1_button = tk.Button(root, text="Price >=40,000AED", command=crypto40k, font=("Times New Roman", 12, "bold"), fg="white", bg="blue", relief="solid", highlightthickness=40)
    option5_option1_button.pack(side="right", padx=10, pady=50, anchor="center") 
def crypto20k():
    clear_window()
    
    # Load the image
    image = Image.open("cryptominers pc low.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_option5_page, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def crypto40k():
    clear_window()
    
    # Load the image
    image = Image.open("cryptominers high.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_option5_page, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()



  


def show_laptop_page1():

    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option5_label = tk.Label(root, text="Choose what kind of laptop you want based on what you'll use it for!", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option5_label.pack()

    option5_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option5_back_button = tk.Button(root, text="Work", command=show_laptop_page2, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option5_option1_button = tk.Button(root, text="Gaming", command=show_laptop_page3, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_laptop_page2():

    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option5_label = tk.Label(root, text="Choose a suitable price for your liking", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option5_label.pack()

    option5_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option5_back_button = tk.Button(root, text="Price<=4,000AED", command=work4k, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option5_option1_button = tk.Button(root, text="Price>=6,000AED", command=work6k, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_option1_button.pack(side="right", padx=10, pady=50, anchor="center")

def work4k():
    clear_window()
    
    # Load the image
    image = Image.open("working laptop low.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_laptop_page2, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def work6k():
    clear_window()
    
    # Load the image
    image = Image.open("working laptop high.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_laptop_page2, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()



def show_laptop_page3():

    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option5_label = tk.Label(root, text="Choose a suitable price for your liking", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option5_label.pack()

    option5_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option5_back_button = tk.Button(root, text="Price<=3,000AED", command=laptop3k, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option5_option1_button = tk.Button(root, text="Price>=5,000AED", command=laptop5k, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option5_option1_button.pack(side="right", padx=10, pady=50, anchor="center")

def laptop3k():
    clear_window()
    
    # Load the image
    image = Image.open("gaming laptop low.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_laptop_page3, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()

def laptop5k():
    clear_window()
    
    # Load the image
    image = Image.open("gaming laptop high.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_laptop_page3, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def show_start_page():
    # Remove the existing content from the GUI
    for widget in root.winfo_children():
        widget.destroy()
        #title of main screen
    root_label = tk.Label(root, text="Welcome to our expert system that will assist you into \n \n" +"choosing the most suitable device based on your preference!", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    root_label.pack(pady=(80,20))
    # Recreate the main screen with the option buttons
    global start_button, option1_button, option2_button, option3_button
    start_button = tk.Button(root, text="Start", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    
    option1_button = tk.Button(root, text="Computer", command=show_option1_page)
    option2_button = tk.Button(root, text="Phone", command=show_option2_page)
    option3_button = tk.Button(root, text="Tablet", command=show_option3_page)
   
    start_button.pack(pady=(80,20))
def show_Iphone_page1():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Would you like a phone that unlocks by your Finger or Face?", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Touch ID", command=show_Iphone_page2, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="Face ID", command=show_Iphone_page5, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_Iphone_page3():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="These are the available options, please pick one from below!", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="iPhone SE", command=iphoneSE, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="iPhone 7", command=iphone7, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")

def iphoneSE():
    clear_window()
    
    # Load the image
    image = Image.open("iphone se.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page3, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def iphone7():
    clear_window()
    
    # Load the image
    image = Image.open("iphone 7.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page3, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack() 



def show_Iphone_page2():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Select your budget so we can assist you further", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Low Budget", command=show_Iphone_page3, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="High Budget", command=show_Iphone_page4, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_Iphone_page4():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of the phones below, whether you like a small or big size phone", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="iPhone 8", command=iphone8, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="iPhone 8+", command=iphone8plus, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")

def iphone8():
    clear_window()
    
    # Load the image
    image = Image.open("iphone 8.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page4, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()



def iphone8plus():
    clear_window()
    
    # Load the image
    image = Image.open("iphone 8 plus.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page4, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack() 


def show_Iphone_page5():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of the options based on your budget", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Low Budget", command=show_Iphone_page6, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="High Budget", command=show_Iphone_page7, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_Iphone_page6():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of these options, as one of them is \n the best seller and the other is the newer version.", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="iPhone XR", command=iphoneXR, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="iPhone 11", command=iphone11, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")

def iphoneXR():
    clear_window()
    
    # Load the image
    image = Image.open("iphone xr.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page6, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def iphone11():
    clear_window()
    
    # Load the image
    image = Image.open("iphone 11.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page6, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
 

def show_Iphone_page7():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of these models, both of them are the same size \n but one is slightly more expensive than the other", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

   

    option6_option1_button = tk.Button(root, text="iPhone 13", command=iphone13, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="iPhone 14", command=iphone14, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def iphone13():
    clear_window()
    
    # Load the image
    image = Image.open("iphone 13.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page7, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def iphone14():
    clear_window()
    
    # Load the image
    image = Image.open("iphone 14.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Iphone_page7, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def show_Android_page1():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose which brand you'd like to buy a phone from", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold")) 
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Huawei", command=show_Android_page2, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="Samsung", command=show_AndroidSAM_page1, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_Android_page2():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one the options based on the limits of your budget", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold")) 
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Low Budget", command=show_Android_page4, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="High Budget", command=show_Android_page5, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_Android_page3():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one the options based on the limits of your budget", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold")) 
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Low Budget", command=show_Iphone_page3, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")

    option6_option1_button = tk.Button(root, text="High Budget", command=show_Iphone_page4, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_Android_page4():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of the options below!", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold")) 
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="HUAWEI Nova Y90", command=Y90, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")
    
    option6_option1_button = tk.Button(root, text="HUAWEI Nova 3i", command=nova3i, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def Y90():
    clear_window()
    
    # Load the image
    image = Image.open("huawei nova y90.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Android_page4, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def nova3i():
    clear_window()
    
    # Load the image
    image = Image.open("huawei nova 3i.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Android_page4, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


    
def show_Android_page5():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of the options below", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold")) 
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="HUAWEI Mate50 Pro", command=mate50, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")
    
    option6_option1_button = tk.Button(root, text="HUAWEI Mate Xs", command=matexs, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def mate50():
    clear_window()
    
    # Load the image
    image = Image.open("huawei mate 50 pro.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Android_page5, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def matexs():
    clear_window()
    
    # Load the image
    image = Image.open("huawei mate xs.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_Android_page5, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def show_AndroidSAM_page1():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of the options based on your budget", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Low Budget", command=show_AndroidSAM_page2, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")
    
    option6_option1_button = tk.Button(root, text="High Budget", command=show_AndroidSAM_page3, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def show_AndroidSAM_page2():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Select one of the phones from below", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Samsung Galaxy A33", command=a33, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")
    
    option6_option1_button = tk.Button(root, text="Galaxy S20 FE", command=s20, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")
def a33():
    clear_window()
    
    # Load the image
    image = Image.open("samsung galaxy a33.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_AndroidSAM_page2, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def s20():
    clear_window()
    
    # Load the image
    image = Image.open("samsung galaxy s20 fe.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_AndroidSAM_page2, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def show_AndroidSAM_page3():
    clear_window()
    # Remove the existing buttons from the GUI
    
    option1_button.destroy()
    option2_button.destroy()
    option3_button.destroy()
    

    # Add a label to the GUI with the option 3 message
    option6_label = tk.Label(root, text="Choose one of the phones from below as your preferred phone", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold")) 
    option6_label.pack()

    option6_back_button = tk.Button(root, text="Back to Main Screen", command=show_main_screen, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="bottom", padx=10, pady=10, anchor="nw")

    # Add buttons to return to the main screen or choose another option
    option6_back_button = tk.Button(root, text="Galaxy S23 Ultra", command=s23, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_back_button.pack(side="left", padx=10, pady=50, anchor="center")
    
    option6_option1_button = tk.Button(root, text="SAMSUNG Galaxy Z Fold4", command=fold4, fg="white", bg="blue", relief="solid", highlightthickness=20, font=("Times New Roman", 12, "bold"))
    option6_option1_button.pack(side="right", padx=10, pady=50, anchor="center")  
def s23():
    clear_window()
    
    # Load the image
    image = Image.open("samsung galaxy s23 ultra.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_AndroidSAM_page3, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()
def fold4():
    clear_window()
    
    # Load the image
    image = Image.open("samsung galaxy z fold4.png")
    image = image.resize((500, 500), Image.ANTIALIAS) # Resize the image
    photo = ImageTk.PhotoImage(image)

    # Create a label to display the image
    image_label = tk.Label(root, image=photo)
    image_label.image = photo
    image_label.pack()

    # Add a button to go back to the previous page
    back_button = tk.Button(root, text="Back", command=show_AndroidSAM_page3, fg="white", bg="blue", bd=2, relief="solid", font=("Times New Roman", 12, "bold"))
    back_button.pack()


def clear_window():
    for widget in root.winfo_children():
        widget.destroy()

def show_main_screen():
    clear_window()
    root_label = tk.Label(root, text="Select which device you want to buy according to these categories", fg="black", bg="gray", relief="solid", font=("Times New Roman", 12, "bold"))
    root_label.pack(pady=(60,20))
    option1_button = tk.Button(root, text="Computer", command=show_option1_page, fg="white", bg="blue", relief="solid", highlightthickness=12, font=("Times New Roman", 12, "bold"))
    option2_button = tk.Button(root, text="Phone", command=show_option2_page, fg="white", bg="blue", relief="solid", highlightthickness=12, font=("Times New Roman", 12, "bold"))
    option3_button = tk.Button(root, text="Tablet", command=show_option3_page, fg="white", bg="blue", relief="solid", highlightthickness=12, font=("Times New Roman", 12, "bold"))
    option1_button.pack(pady=(60,20))
    option2_button.pack(pady=20)
    option3_button.pack(pady=20)




    

# Create the GUI
root = tk.Tk()
root.iconbitmap('tech.ico')
root.configure(background="#042C71")
root.title("Tech support")
root.geometry("600x600")

# Show the main screen
show_start_page()



# Start the GUI event loop
root.mainloop()